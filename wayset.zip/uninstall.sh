#!/bin/bash

sudo rm /usr/local/bin/wayset
sudo rm -r /usr/share/wayset
rm -r ~/.logos
rm ~/.local/share/applications/wayset.desktop
