#!/bin/bash

sudo cp wayset /usr/local/bin/wayset
sudo cp -r usr /
cp .logos -r ~/
cp wayset.desktop ~/.local/share/applications/
